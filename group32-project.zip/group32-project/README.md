# CS325-TSP-Project
Traveling Salesman Project

By Alexander Nead-Work, Alexander Rash, and Lyell Read

# How to Run

`python3 nn.py <input_file>`
